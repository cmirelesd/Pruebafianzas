# Dashboard Fianzas

Dashboard React para visualizar contratos públicos y detectar oportunidades con fianza sugerida.

## 🚀 Stack
- React + Vite
- Tailwind CSS
- React Router
- PapaParse para procesar CSV

## 🧪 Cómo correrlo localmente
```bash
npm install
npm run dev
```

## ✅ Login
Usuario: `Cmireles`  
Contraseña: `Charly`
